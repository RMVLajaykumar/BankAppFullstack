import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { depositMoney } from '../../../../services/CustomerServices';
import { successToast, errorToast } from '../../../utils/toast';
import { Button } from 'react-bootstrap';
import './DepositConfirmation.css'
import 'react-toastify/dist/ReactToastify.css'; 
import { ToastContainer } from 'react-toastify';


const DepositConfirmation = () => {
  const { accountNumber, amount } = useParams();
  const navigate = useNavigate();

  const handleConfirm = async () => {
    try {
      await depositMoney(accountNumber, amount);
      successToast('Deposit successful!');
      setTimeout(() => {
        navigate(`/user-dashboard/${localStorage.getItem("id")}`);
      }, 1000);
    } catch (error) {
      errorToast('Deposit failed.');
    }
  };

  const handleCancel = () => {
    navigate('/user-dashboard');
  };

  return (
    <div className="transaction-confirmation">
      <h2>Deposit Confirmation</h2>
      <p><strong>Account Number:</strong> {accountNumber}</p>
      <p><strong>Amount:</strong> {amount}</p>
      <div className="buttons">
        <Button variant="success" onClick={handleConfirm}>
          Confirm
        </Button>
        <Button variant="danger" onClick={handleCancel}>
          Cancel
        </Button>
      </div>
      <ToastContainer />
    </div>
  );
};

export default DepositConfirmation;
